<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 class admin extends CI_Controller {
      //functions  
	  	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		 $this->load->library('session');
			}
	   	public function adlogin()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/login');

  }
  	 	public function adindex()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/index');

  }
  	 	public function adregister()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/register');

  }
  public function adforgotpassword()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/forgot-password');

  }
    public function addmenu()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/addmenu');

  }
  public function admenu()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/menus');

  }
   public function addsub()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/addsub');

  }
  public function adsub()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/submenus');

  }
   public function adduser()
	{
		//$this->load->view('welcome_message');

	
		$this->load->view('admin/adduser');

  }
  public function aduser()
	{
		//$this->load->view('welcome_message');
  $this->load->model('admin_model');  
         //load the method of model  
         $data['h']=$this->admin_model->user();  
	
		$this->load->view('admin/registered',$data);

  }
   public function  addproduct()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/addproduct');

  }
     public function  adproduct()
	{
		//$this->load->view('welcome_message');
		  $this->load->model('admin_model');  
         //load the method of model  
         $data['h']=$this->admin_model->product(); 
	
		$this->load->view('admin/products',$data);

  }
  
     public function  addorder()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/addorder');

  }
     public function  adorder()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/orders');

  }
  	public function admail()
	{
		//$this->load->view('welcome_message');
	
		$this->load->view('admin/mail');

  }
      function login()  
      {  		

           //http://localhost/tutorial/codeigniter/main/login  
           $data['title'] = 'CodeIgniter Simple Login Form With Sessions';  
           $this->load->view("admin/login", $data);  
      }  
      function login_validation()  
      {  		 $this->load->library('session');

           $this->load->library('form_validation');  
           $this->form_validation->set_rules('username', 'Username', 'required');  
           $this->form_validation->set_rules('password', 'Password', 'required');  
       if($this->form_validation->run())  
           {  
                //true  
                $username = $this->input->post('username');  
                $password = $this->input->post('password');  
                //model function  
                $this->load->model('main_model');  
                if($this->main_model->can_login($username, $password))  
                {  
                     $session_data = array(  
                          'username'     =>     $username  
                     );  
                     $this->session->set_userdata($session_data);  
					 		$this->load->view('admin/index');

                  } 
                else  
                {  
                     $this->session->set_flashdata('error', 'Invalid Username and Password');  
		$this->load->view('admin/login');
                }  
           }  
           else  
           {  
                //false  
                $this->login();  
           }  
      }  
      function enter(){  
	  		 $this->load->library('session');

           if($this->session->userdata('username') != '')  
           {  
                echo '<h2>Welcome - '.$this->session->userdata('username').'</h2>';  
                echo '<label><a href="'.base_url

().'admin/logout">Logout</a></label>';  
           }  
           else  
           {  
						$this->load->view('admin/login');

           }  
      }  
      function logout() 
	  
      {  
           $this->session->unset_userdata('username');  
		$this->load->view('admin/login');
      }  
	 public function deleted($id = '') {
		 	 $this->session->set_flashdata('message', 'User Deleted Sucessfully.');

  $this->load->model('admin_model');
  $where = array('id' => $id); 
  $this->admin_model->deleteRecord('register',$where);
    $data['h']=$this->admin_model->user();  
	
  		$this->load->view('admin/registered',$data);
		}
function addproducts()
	
	{
			$this->load->library('session');
		$this->load->model('admin_model');

			if($this->input->post('save'))
		{
		//this array is used to get fetch data from the view page.
		$data = array(
						'name'     => $this->input->post('name'),
						'description'  => $this->input->post('des'),
						'price'   => $this->input->post('price'),
						'picture'   => $this->input->post('picture'),

					
						);
						 $this->admin_model->hey($data); 
						 $this->session->set_flashdata('message', 'Sucessfully Registered.');


$this->load->view("admin/addproduct");
         
         //  else{
           //    $this->session->set_flashdata("message","Record Not Updated!");
             //  redirect('orderManagement/index', 'refresh');
           //}
		//insert data into database table.

	}
	}
 }  