<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->home();
    $this->data['wo'] = $this->Cart_model->home2();
	    $this->data['bag'] = $this->Cart_model->home3();
		    $this->data['foot'] = $this->Cart_model->home4();
		


		
		$this->load->view('index', $this->data);
		
		// $this->data['title'] = 'Shopping Carts';

		// if (!$this->cart->contents()){
		// 	$this->data['message'] = '<p>Your cart is empty!</p>';
		// }else{
		// 	$this->data['message'] = $this->session->flashdata('message');
		// }

		// $this->load->view('cart', $this->data);

		

//$this->load->view('data/main.php');

	}
	
	public function index1()
	{
		//$this->load->view('welcome_message');
		$this->load->view('about1.php');


//$this->load->view('data/main.php');

	}
	public function index2()
	{
		//$this->load->view('welcome_message');
				$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->men();
		
		$this->load->view('mens', $this->data);


//$this->load->view('data/main.php');

	}
	
		public function index3()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->getdata();
		
		$this->load->view('womens', $this->data);
  }

 
			


//$this->load->view('data/main.php');

			public function index4()
	{
		//$this->load->view('welcome_message');
				$this->load->view('contact.php');


//$this->load->view('data/main.php');

	}
		public function index5()
	{
		//$this->load->view('welcome_message');
								$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->single();
		
		$this->load->view('single', $this->data);


//$this->load->view('data/main.php');

	}

	public function index6()
	{
		//$this->load->view('welcome_message');
				$this->load->view('typography.php');


//$this->load->view('data/main.php');

	}
		public function index7()
	{
		//$this->load->view('welcome_message');
				$this->load->view('icons.php');


//$this->load->view('data/main.php');

	}
	
	function savingdata()
	{	$this->load->model('Cart_model');

			if($this->input->post('save'))
		{
		//this array is used to get fetch data from the view page.
		$data = array(
						'name'     => $this->input->post('name'),
						'email'  => $this->input->post('email'),
						'password'   => $this->input->post('pass'),
					
						);
						 $this->Cart_model->hey($data); 

          
         //  else{
           //    $this->session->set_flashdata("message","Record Not Updated!");
             //  redirect('orderManagement/index', 'refresh');
           //}
		//insert data into database table.

		redirect("welcome/index5");
	}
	}
	public function add()
	{
		
		$this->load->model('Cart_model');
	$this->load->helper('form');
		$insert_room = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'price' => $this->input->post('price'),
			'qty' => 1
		);		
$this->load->view('cart.php');
$this->cart->insert($insert_room);
			
		redirect('womens');
	}
	
	function remove($rowid) {
		if ($rowid=="all"){
			$this->cart->destroy();
		}else{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);

			$this->cart->update($data);
		}
		
		redirect('cart');
	}	

	function update_cart(){
 		foreach($_POST['cart'] as $id => $cart)
		{			
			$price = $cart['price'];
			$amount = $price * $cart['qty'];
			
			$this->Cart_model->update_cart($cart['rowid'], $cart['qty'], $price, $amount);
		}
		
		redirect('cart');
	}	

	
	public function get(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->getdata();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('womens', $data);
 }
 	public function men(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->men();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('mens', $data);
 }
	public function home(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home2(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home2();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home3(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home3();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home4(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home4();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function single(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->single();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('single', $data);
 }
 
}
