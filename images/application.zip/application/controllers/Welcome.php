<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
  
 
	public function index()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->home();
    $this->data['wo'] = $this->Cart_model->home2();
	    $this->data['bag'] = $this->Cart_model->home3();
		    $this->data['foot'] = $this->Cart_model->home4();
		


		
		$this->load->view('index', $this->data);
		
		// $this->data['title'] = 'Shopping Carts';

		// if (!$this->cart->contents()){
		// 	$this->data['message'] = '<p>Your cart is empty!</p>';
		// }else{
		// 	$this->data['message'] = $this->session->flashdata('message');
		// }

		// $this->load->view('cart', $this->data);

		

//$this->load->view('data/main.php');

	}
	
	public function index1()
	{
		//$this->load->view('welcome_message');
		$this->load->view('about.php');


//$this->load->view('data/main.php');

	}
	public function homeindex()
	{
		
$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->home();
    $this->data['wo'] = $this->Cart_model->home2();
	    $this->data['bag'] = $this->Cart_model->home3();
		    $this->data['foot'] = $this->Cart_model->home4();
					 

	
		if($this->session->userdata('register')){
			

		$this->load->view('fatch.php', $this->data);
		
		}
		else{
			redirect('/');
		}
		
	}
	public function username()
	{
		 $this->load->library('session');
		$this->load->model('users_model');
		$this->session->userdata('email');
		$users=$this->users_model->loginname();
		print_r($users);
	}
	public function aboutindex()
	{ $this->load->library('session');



		//restrict users to go to home if not logged in
		if($this->session->userdata('register')){
			$this->load->view('about1.php');
		}
		else{
			redirect('/');
		}
		

	}
	function remove2($rowid) {
		if ($rowid=="all"){
			$this->cart->destroy();
		}else{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);

			$this->cart->update($data);
		}
		
		redirect('welcome/homeindex');
	}	
	public function index2()
	{
		//$this->load->view('welcome_message');
				$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->men();
		
		$this->load->view('mens', $this->data);


//$this->load->view('data/main.php');

	}
	public function menindex()
	{
		//$this->load->view('welcome_message');
				$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->men();
		
		
		$this->load->library('session');

		if($this->session->userdata('register')){
			$this->load->view('mens1', $this->data);
		}
		else{
			redirect('/');
		}


//$this->load->view('data/main.php');

	}
	public function womenindex()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->getdata();
		
		
			$this->load->library('session');

		if($this->session->userdata('register')){
			$this->load->view('womens1', $this->data);
		}
		else{
			redirect('/');
		}

  }

	
		public function index3()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->getdata();
		
		$this->load->view('womens', $this->data);
  }

 
			


//$this->load->view('data/main.php');

			public function index4()
	{
		//$this->load->view('welcome_message');
				$this->load->view('contact.php');


//$this->load->view('data/main.php');

	}
			public function contactindex()
	{
		//$this->load->view('welcome_message');
				
$this->load->library('session');

		if($this->session->userdata('register')){
			$this->load->view('contact1.php');
		}
		else{
			redirect('/');
		}

//$this->load->view('data/main.php');

	}
		public function index5()
	{
		//$this->load->view('welcome_message');
								$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->single();
		
		$this->load->view('single', $this->data);


//$this->load->view('data/main.php');

	}
	public function continueshop()
	{
		//$this->load->view('welcome_message');
								$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->single();
		
		$this->load->view('single1', $this->data);


//$this->load->view('data/main.php');

	}
	public function webindex()
	{
		//$this->load->view('welcome_message');
								$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->single();
		
		
$this->load->library('session');

		if($this->session->userdata('register')){
			$this->load->view('icons1.php');
		}
		else{
			redirect('/');
		}


//$this->load->view('data/main.php');

	}
	public function typoindex()
	{
		//$this->load->view('welcome_message');
				
$this->load->library('session');

		if($this->session->userdata('register')){
			$this->load->view('typography1.php');
		}
		else{
			redirect('/');
		}

//$this->load->view('data/main.php');

	}

	public function index6()
	{
		//$this->load->view('welcome_message');
				$this->load->view('typography.php');


//$this->load->view('data/main.php');

	}
		public function index7()
	{
		//$this->load->view('welcome_message');
				$this->load->view('icons.php');


//$this->load->view('data/main.php');

	}
	
	function savingdata()
	{	$this->load->model('Cart_model');

			if($this->input->post('save'))
		{
		//this array is used to get fetch data from the view page.
		$data = array(
						'name'     => $this->input->post('name'),
						'email'  => $this->input->post('email'),
						'password'   => $this->input->post('pass'),
					
						);
						 $this->Cart_model->hey($data); 

          						 $this->session->set_flashdata('message', 'Sucessfully Registered.');

         //  else{
           //    $this->session->set_flashdata("message","Record Not Updated!");
             //  redirect('orderManagement/index', 'refresh');
           //}
		//insert data into database table.

		redirect("welcome/index5");
	}
	}

	public function add()
	{
		
		$this->load->model('Cart_model');
	$this->load->helper('form');
		$insert_room = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'price' => $this->input->post('price'),
			'qty' => 1
		);		
$this->load->view('cart.php');
$this->cart->insert($insert_room);
			
		redirect('womens');
	}
	
	function remove($rowid) {
		if ($rowid=="all"){
			$this->cart->destroy();
		}else{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);

			$this->cart->update($data);
		}
		
		redirect('cart');
	}	

function remove1($rowid) {
		if ($rowid=="all"){
			$this->cart->destroy();
		}else{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);

			$this->cart->update($data);
		}
		
		redirect('cart1');
	}	

	function update_cart(){
 		foreach($_POST['cart'] as $id => $cart)
		{			
			$price = $cart['price'];
			$amount = $price * $cart['qty'];
			
			$this->Cart_model->update_cart($cart['rowid'], $cart['qty'], $price, $amount);
		}
		
		redirect('cart');
	}	

function update_cart1(){
 		foreach($_POST['cart'] as $id => $cart)
		{			
			$price = $cart['price'];
			$amount = $price * $cart['qty'];
			$this->load->model('Cart_model');
			$this->Cart_model->update_cart($cart['rowid'], $cart['qty'], $price, $amount);
		}
		
		redirect('cart1');
	}	

	
	public function get(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->getdata();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('womens', $data);
 }
 	public function men(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->men();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('mens', $data);
 }
	public function home(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home2(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home2();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home3(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home3();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function home4(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->home4();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('index', $data);
 }
 public function single(){
 $this->load->model('Cart_model');
  $query = $this->Cart_model->single();
  $data['result'] = null;
  if($query){
   $data['result'] = $query;
  }

  $this->load->view('single', $data);
 }
  	 public function profile(){
  	 $data = array();
	   $this->load->model('Users_model');
   	$data['result']=$this->Users_model->namedisplay();
     $this->load->view('profile.php',$data);
//$this->load->view('profile.php');
    if ($this->input->post('save2')) {
        $this->Users_model->updatename();

   	// $data1['result']=$this->Users_model->namedisplay();
   	// print_r($data1);
        redirect('welcome/profile');
     //$this->load->view('profile.php',$data1);
  
     
       
            }
 if ($this->input->post('emailsave')) {
        $this->Users_model->updateemail();
   //$data= $this->input->Post('email');
        $result1 = array('email' => $_POST['email']);

       $this->load->view('profile.php');
            }
      if ($this->input->post('changepass')) {
		
           $this->Users_model->updatepass();
          $this->load->view('profile.php');

    
            }

		
        
	    
	  
  }
   public function order(){
   	 $this->load->model('Users_model');
	  $id = $this->session->userdata('id');
	  
	  
	//  print_r($result);

   $data['records']  = $this->Users_model->order_details($id);

$this->load->view('order.php',$data);
	    // $this->load->view('order.php');
	  
  }
     public function seek()
{
    // this is the artist search display
  $art = html_escape(trim($this->input->post('search')));
  $this->db->like('name', $art);
  $this->db->select('name, description, price, picture');
  $query = $this->db->get('new');
  $num = $query->num_rows();

  echo "<h3>We found $num $art product's</h3>";
  if($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
         echo "<li class='search_list'>name: $row->name <br> Album: $row->description <br> Podcast: $row->price</li> ";
     }
	 
	 
  }else {
      echo "You searched for $art, Please check your spelling, or ensure the artists name is complete";
    }
}
  public function profile1(){
  	 $data = array();
	   
	   $this->load->model('Users_model');
   	$data['result']=$this->Users_model->namedisplay();
     $this->load->view('billing1.php',$data);
     if ($this->input->post('save2')) {
        $this->Users_model->updatename();

   	
        redirect('welcome/profile1');
    
  
     
       
            }

 if ($this->input->post('emailsave')) {
        $this->Users_model->updateemail();
  
         redirect('welcome/profile');

 
            }
             if ($this->input->post('changepass')) {
             	
             	$this->Users_model->updatepass();

             	   redirect('welcome/profile');
   // $this->session->flashdata('success','chnge');
             	   $this->session->set_flashdata('message_name', 'chnaged');
			 }
            }
        
	    

	
}
