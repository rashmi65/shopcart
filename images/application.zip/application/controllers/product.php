<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	
	
		public function productall()
	{
		//$this->load->view('welcome_message');
		$this->load->model('Cart_model');
  $this->data['products'] = $this->Cart_model->getdata();
		
		$this->load->view('product', $this->data);
	}

public function get_productid($id)//this know only one parameter will be come to this
{
	$this->load->model('data_model');
	  $data['details']=$this->data_model->get_details($id);//passing the product id to get details of your product
	
  $this->load->view('product_single', $data);
}
public function get_men($id)//this know only one parameter will be come to this
{
	$this->load->model('data_model');
	  $data['details']=$this->data_model->get_men($id);//passing the product id to get details of your product
	
  $this->load->view('product_single', $data);
}
public function get_home($id)//this know only one parameter will be come to this
{
	$this->load->model('data_model');
	  $data['details']=$this->data_model->get_home($id);//passing the product id to get details of your product
	
  $this->load->view('product_single', $data);
}
}