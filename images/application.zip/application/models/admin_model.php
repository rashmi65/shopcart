<?php  
   class admin_model extends CI_Model  
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct();  
      }  
      //we will use the select function  
      public function user()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('register');  
         return $query;  
      } 
	   public function product()  
      {  
         //data is retrive from this query  
         $query = $this->db->get('new');  
         return $query;  
      } 
public function deleteRecord($table, $where = array()) {
  $this->db->where($where);
  $res = $this->db->delete($table); 
  if($res)
    return TRUE;
  else
    return FALSE;
}
	function hey($data){ 
  $this->db->insert('new', $data); // insert data into register table

 }	  
   }  
?>  