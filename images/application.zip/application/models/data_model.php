<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Data_model extends CI_Model {

public function get_details($id)
    {
        $query = $this->db->query("SELECT * FROM products WHERE serial='$id'");
        $result = $query->result_array();
        return $result; //return as object array
    }
	public function get_men($id)
    {
        $query = $this->db->query("SELECT * FROM mendata WHERE serial='$id'");
        $result = $query->result_array();
        return $result; //return as object array
    }
		public function get_home($id)
    {
        $query = $this->db->query("SELECT * FROM new WHERE serial='$id'");
        $result = $query->result_array();
        return $result; //return as object array
    }
	
}