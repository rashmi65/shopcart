<?php
	class Users_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function login($email, $password){
			// $query = $this->db->get('register');

			$users = $this->db

           -> select('name')
           -> where('email', $email)
           -> limit(1)
           -> get('register ');
           //echo "name is" . $users;
			$query = $this->db->get_where('register', array('email'=>$email, 'password'=>$password));

			return $query->row_array();
}

		public function loginname(){
			$email=$this->session->userdata('email');
			
$this->load->database();
					
			  $this->db->select('name');
    // $this->db->from('register');
    $this->db->where('email', $email);
   $users = $this->db->get('register');
		
   //  $query=$this->db->get();
   // $variable = $query->row('name');
   //  return $variable->result();

 if($users->num_rows() > 0) {
    	
 $users = $users->row('name');
 
   //echo $users;
return $users;    
} else {
     return FALSE;
}
    
   
   // $result=$query->result();
			// $query = $this->db->get('register');
			
		
}
 public function updatename()
{


$column_id_value=$this->session->userdata('email');
$value=  $this->input->Post('name');
$this->db->set('name', $value); //value that used to update column  
$this->db->where('email', $column_id_value); //which row want to upgrade  
$this->db->update('register');

	//print_r($value);
//$query="select name from register where name=$value";
 // return $value->result();
}
public function updateemail()
{$column_id_value=$this->session->userdata('email');
$value=  $this->input->Post('email');
$this->db->set('email', $value); //value that used to update column  
$this->db->where('email', $column_id_value); //which row want to upgrade  
$this->db->update('register');
}
public function updatepass()
{$column_id_value=$this->session->userdata('password');
$value=  $this->input->Post('password');


$this->db->set('password', $value); //value that used to update column  
$this->db->where('password', $column_id_value); //which row want to upgrade  
$this->db->update('register');

}
public function namedisplay()
{$column_id_value=$this->session->userdata('email');
    // $query=$this->db->query("select * from register where name=$column_id_value");
$q = $this -> db
          -> select('name,email,address,phone,state,city,pincode,country')
          -> where('femail', $column_id_value)
         
          -> get('customers');

return $q->result();
}
public function namedisplay1()
{$column_id_value=$this->session->userdata('email');
     // $query=$this->db->query("select * from register where name=$column_id_value");
	$q = $this -> db
           -> select('name')
           -> where('email', $column_id_value)
          
           -> get('register');
	 
	return $q->result();
}
public function emaildisplay()
{$column_id_value=$this->session->userdata('email');
     //$q1=$this->db->query("select email from register where email=$column_id_value");
	$q1 = $this -> db
      -> select('email')
      -> where('email', $column_id_value)
          
     -> get('register');
	
	  //print_r($q1->result());
	return $q1->result();
}
 
 
 
 
 
 
public function displayrecords()
{$column_id_value=$this->session->userdata('name');
     // $query=$this->db->query("select * from register where name=$column_id_value");
	$q = $this -> db
           -> select('*')
           -> where('name', $column_id_value)
          
           -> get('register');
	 
	return $q->result();
}

public function order_details($id)
{
	 $this->db->where('user_id',$id);
    $query=$this->db->get('payment');

    return $query->result();

	}
	public function search()
{
	   // this is the artist search display
  $art = html_escape(trim($this->input->post('search')));
  $this->db->like('name', $art);
  $this->db->select('name, description, price, picture');
  $query = $this->db->get('new');
  //$num = $query->num_rows();
 // $query->result();
    return $query->result();

	}
	
	}
	
?>