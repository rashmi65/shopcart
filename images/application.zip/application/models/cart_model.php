<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cart_model extends CI_Model {

	public function __construct()
	{
		//$this->load->database();
	}

	public function getdata()
	{
 $query = $this->db->get('products');
		return $query->result_array();
 
	}
		public function men()
	{
 $query = $this->db->get('mendata');
		return $query->result_array();
 
	}
	public function home()
	{
		
		
		$this->db->where('description', 'mens');
		$query = $this->db->get('new');
      $query->result_array();
		//$sql="select * from new where description='mens'"
		//$query=mysqli($)
 //$query = $this->db->get('new');
 
		return $query->result_array();
 
	}
		public function home2()
	{
		
		
		$this->db->where('description', 'womens');
		$query = $this->db->get('new');
      $query->result_array();
		//$sql="select * from new where description='mens'"
		//$query=mysqli($)
 //$query = $this->db->get('new');
 
		return $query->result_array();
 
	}
	public function home3()
	{
		
		
		$this->db->where('description', 'bag');
		$query = $this->db->get('new');
      $query->result_array();
		//$sql="select * from new where description='mens'"
		//$query=mysqli($)
 //$query = $this->db->get('new');
 
		return $query->result_array();
 
	}
	public function home4()
	{
		
		
		$this->db->where('description', 'footwear');
		$query = $this->db->get('new');
      $query->result_array();
		//$sql="select * from new where description='mens'"
		//$query=mysqli($)
 //$query = $this->db->get('new');
 
		return $query->result_array();
 
	}
	
	
	function update_cart($rowid, $qty, $price, $amount) {
 		$data = array(
			'rowid'   => $rowid,
			'qty'     => $qty,
			'price'   => $price,
			'amount'   => $amount
		);
		

		$this->cart->update($data);
	}
	function hey($data){ 
  $this->db->insert('register', $data); // insert data into register table

 }
 public function single()
	{

 $query = $this->db->get('new');
		return $query->result_array();
 
	}
   
   // function get_submenu()
   // {
//$this->db->query("SELECT * FROM sub_menu JOIN main_menu ON sub_menu.`m_menu_id` = main_menu.`m_menu_id`	
//");
	//SELECT main_menu.`m_menu_name`,sub_menu.`s_menu_name` FROM sub_menu JOIN main_menu ON sub_menu.`m_menu_id` = main_menu.`m_menu_id`	
		
        // $this->db->where(sub_menu.`m_menu_id` = main_menu.`m_menu_id`);
        // $this->db->select('*');
        // $this->db->from('sub_menu');
       // $this->db->join('main_menu', sub_menu.`m_menu_id` = main_menu.`m_menu_id`,'inner');
        // $query = $this->db->get(sub_menu);
		// print_r($query);
		//exit;
       // return $query->result();
	//}
	
}