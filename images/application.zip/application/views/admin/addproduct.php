
<?php include ('header1.php'); ?>



  <body id="page-top">

   <?php include ('nav.php'); ?>


    <div id="wrapper">
<?php include ('sidebar.php'); ?>

      

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
	<?php if($this->session->flashdata('message')){?>
   <div class="alert alert-success">      
    <?php echo $this->session->flashdata('message')?>
 </div>
 <?php } ?>
          <!-- Icon Cards-->
          <div class="row">
		  
        <div class="card-body">
		<h2>Add A Product</h2>
	<form action="<?php echo site_url('admin/addproducts'); ?>" method="post" onSubmit="Check();">
            <div class="form-group">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" class="form-control" name="name" placeholder="Product name" required="required" autofocus="autofocus">
                    <label for="firstName">Name</label>
                  </div>
                </div>
              
              </div>
         
            <div class="form-group">
			        <div class="col-md-6">
              <div class="form-label-group">
			             

                <input type="text" id="inputEmail" name="des" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">Category</label>
              </div>
			  </div>
            </div>
            <div class="form-group">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="number" name="price" class="form-control" placeholder="price" required="required">
                    <label for="inputPassword">price</label>
                 
                </div>
				</div>
				</div>
				  <div class="form-group">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="file" name="picture" required="required">
                  </div>
              </div>
            </div>
		<input class="btn btn-primary col-md-6" type="submit" value="Register" name="save">

          </form>
        
        </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © shopcart 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?php echo site_url('admin/adlogin')?>">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}
     function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
		}
	</script>

  </body>
<?php include ('footer1.php'); ?>

</html>
