
<?php 
include 'header.php';
?><?php
$grand_total = 0;

if ($cart = $this->cart->contents()):
	foreach ($cart as $item):
		$grand_total = $grand_total + $item['subtotal'];
	endforeach;
endif;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  
<!------------------------------------------------------STYLE------------------------------------------------------------------------------->
    
<link rel="stylesheet" href="css/stylesheet.css">    
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Billing Info</title>
</head>
<body>
<form name="billing" method="post" action="<?php echo site_url('billing/save_order'); ?>">
    <input type="hidden" name="command" />
<br>
	<div align="center">
        <h1 align="center">Billing Info</h1>
<br>
		<div>
        <table border="0" cellpadding="2px" >
        	<tr><td>Order Total:</td><td><strong>$<?php echo number_format($grand_total,2); ?></strong></td></tr>
            <tr><td>Your Name:</td><td><input type="text" name="name" class="form-control" required/></td></tr>
            <tr><td>Address:</td><td><input type="text" name="address" class="form-control" required/></td></tr>
            <tr><td>Email:</td><td><input type="email" name="email"  class="form-control" required/></td></tr>
            <tr><td>Phone:</td><td><input type="number" name="phone" class="form-control" required/></td></tr>
            <tr><td>&nbsp;</td><td><input type="submit" value="Place Order" class="btn btn-primary"/></td></tr>
        </table>
	</div>
	</div>
</form>
</body>
</html>
<?php 
include 'footer.php';
?>