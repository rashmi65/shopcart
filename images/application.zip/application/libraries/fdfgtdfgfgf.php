        $returnURL = base_url().'index.php/paypal/success'; //payment success url
       $cancelURL = base_url().'index.php/paypal/cancel'; //payment cancel url
       $notifyURL = base_url().'index.php/paypal/ipn'; //ipn url
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('cancel_return', $cancelURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        // Get product data
		foreach ($this->cart->contents() as $key =>$item) {
echo "<pre>";
print_r($item);
echo "</pre>";
?>
<input type="hidden" value="<?php echo $item['name'];?>">
<?php
		 $this->paypal_lib->add_field('item_name', $item['name']);
        // $this->paypal_lib->add_field('item_name', $item);
        // $this->paypal_lib->add_field('item_number',  $item);
        // $this->paypal_lib->add_field('amount',  $item);
        
      
     
     
       


	}
   $this->paypal_lib->paypal_auto_form();
   <?php
		
			foreach ($this->cart->contents() as $key =>$item) {

			
			// echo "<pre>";
 //print_r($item);
// echo "</pre>";
?>


      <input type="hidden" name="cmd" value="_s-xclick">
	  
	          <input type="hidden" name="business" value="amitesh.sharma-facilitator@gmail.com">

      
<input type="hidden" name="item_name" value="<?php echo $item['name'];?>">

<input type="hidden" name="price" value="<?php echo $item['price'];?>">
<?php		

}
?>